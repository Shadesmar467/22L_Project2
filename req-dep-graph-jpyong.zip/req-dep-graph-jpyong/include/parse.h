#ifndef PARSE_H
#define PARSE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void parse_SRS(char* file); //this function will parse the entire input file and withdraw the names of the modules to sort


#endif PARSE_H