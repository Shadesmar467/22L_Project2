#include "tree.h"

Node* newNode(const char* mName) {
    //this function is currently a stub, but it will be implemented at a later date.
}

Node* addSibling(Node* n, const char* mName) {
    //this function is currently a stub, but it will be implemented at a later date.
}

Node* addChild(Node* n, const char* mName) {
    //this function is currently a stub, but it will be implemented at a later date.
}

