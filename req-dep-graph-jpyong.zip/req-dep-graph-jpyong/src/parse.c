#include "parse.h"
//#include <regex.h> research regex in minGW, may need emulator

void parse_SRS(char* file) {
    //this function is currently a stub, but it will be implemented at a later date.
}