#include <stdio.h>

#include "parse.h"
#include "tree.h"

int main() {
    //this function is currently a stub, but it will be implemented at a later date.
    return 0;
}